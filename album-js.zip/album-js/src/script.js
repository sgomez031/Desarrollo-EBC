//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://i.pinimg.com/736x/7b/a2/93/7ba29301fd06025648a8a8ba16af5d6f.jpg",
  "https://i.pinimg.com/736x/23/a3/cc/23a3cc98d1299826e64329815a6fd290.jpg",
  "https://i.pinimg.com/736x/e8/40/a8/e840a828ba5a627981738d546dac6ef7.jpg",
  "https://i.pinimg.com/736x/bd/ab/67/bdab6743d77284bd626c304bd904fc72.jpg",
  "https://i.pinimg.com/736x/2e/7c/2d/2e7c2d364a003996300aa5953e913496.jpg",
  "https://i.pinimg.com/736x/57/ae/2c/57ae2c296401a96213a500bfde58afc5.jpg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});
     