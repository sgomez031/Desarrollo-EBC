# Album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/SANTIAGO-GOMEZRUIZ/pen/JoYVqPV](https://codepen.io/SANTIAGO-GOMEZRUIZ/pen/JoYVqPV).

